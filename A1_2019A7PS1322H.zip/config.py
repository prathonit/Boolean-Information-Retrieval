DATASET_PATH = "information_source/"
FILE_INDEX_PATH = "data/files.pk"
INVERTED_INDEX_PATH = "data/inverted_index.pk"
PERMUTERM_INDEX_PATH = "data/perm_index.pk"
